﻿namespace Good.GameObjects
{
    /// <summary>
    /// Класс представляющий игровой объект - дерево
    /// </summary>
    class Tree
    {
    }
}
