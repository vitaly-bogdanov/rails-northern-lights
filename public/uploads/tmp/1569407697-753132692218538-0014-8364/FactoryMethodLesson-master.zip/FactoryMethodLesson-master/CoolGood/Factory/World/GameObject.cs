﻿
namespace Factory.World
{
    /// <summary>
    /// Базовый класс для игрового мира
    /// </summary>
    class GameObject
    {
    }
}
