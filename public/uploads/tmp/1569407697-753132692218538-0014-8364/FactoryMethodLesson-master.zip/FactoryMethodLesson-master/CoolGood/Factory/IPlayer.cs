﻿
namespace Factory
{
    /// <summary>
    /// Интерфейс представляющий игрока
    /// </summary>
    interface IPlayer
    {
    }
}
