﻿
namespace Factory.World
{
    /// <summary>
    /// Класс представляющий скамейки
    /// </summary>
    class Bench : GameObject
    {

    }
}
