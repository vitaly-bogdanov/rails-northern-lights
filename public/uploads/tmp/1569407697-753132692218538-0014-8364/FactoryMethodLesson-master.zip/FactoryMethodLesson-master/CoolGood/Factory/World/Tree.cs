﻿
namespace Factory.World
{
    /// <summary>
    /// Класс представляющий деревья
    /// </summary>
    class Tree : GameObject
    {
    }
}
