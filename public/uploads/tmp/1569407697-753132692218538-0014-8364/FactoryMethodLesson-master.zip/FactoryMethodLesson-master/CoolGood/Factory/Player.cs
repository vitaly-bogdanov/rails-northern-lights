﻿
namespace Factory
{
    /// <summary>
    /// Класс представляющий игрока
    /// </summary>
    class Player : IPlayer
    {
    }
}
