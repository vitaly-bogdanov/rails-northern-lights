﻿namespace Bad
{
    /// <summary>
    /// Абстракция для быдло
    /// 
    /// Если не понятно зачем нужны интерфейсы чекай этот видос:
    /// https://youtu.be/fu13d1V73K4
    /// 
    /// </summary>
    interface IBidlo
    {
        /// <summary>
        /// Каждое быдло может издавать боевой клич
        /// </summary>
        void BatleRoar();
    }
}
