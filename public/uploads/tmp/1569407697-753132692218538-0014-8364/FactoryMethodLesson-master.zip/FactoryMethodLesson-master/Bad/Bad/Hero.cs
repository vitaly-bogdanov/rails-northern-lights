﻿namespace Bad
{
    /// <summary>
    /// Класс представляющий главного героя
    /// </summary>
    class Hero
    {
    }
}
