﻿namespace Bad.GameObjects
{
    /// <summary>
    /// Класс представляющий игровой объект - скамейку
    /// </summary>
    class Bench
    {
    }
}
