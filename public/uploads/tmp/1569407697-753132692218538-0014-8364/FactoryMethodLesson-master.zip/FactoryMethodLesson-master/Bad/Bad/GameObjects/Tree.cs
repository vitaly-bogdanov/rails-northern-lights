﻿namespace Bad.GameObjects
{
    /// <summary>
    /// Класс представляющий игровой объект - дерево
    /// </summary>
    class Tree
    {
    }
}
